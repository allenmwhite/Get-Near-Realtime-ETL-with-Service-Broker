USE [MASTER] 
ALTER DATABASE [AdventureWorks] SET NEW_BROKER
GO

USE AdventureWorks
GO

CREATE MASTER KEY
       ENCRYPTION BY PASSWORD = N'D8CT93u8XAr4ctcBopX7V7dm';
GO

CREATE USER SyncUser WITHOUT LOGIN;
GO
CREATE CERTIFICATE SyncCert 
     AUTHORIZATION SyncUser
     WITH SUBJECT = 'Sync Certificate',
          EXPIRY_DATE = N'12/31/2020';

BACKUP CERTIFICATE SyncCert
  TO FILE = N'C:\Certs\SyncCert.cer';
GO

CREATE MESSAGE TYPE [//AsyncSync/Customer] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//AsyncSync/Product] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE MESSAGE TYPE [//AsyncSync/Contact] 
AUTHORIZATION dbo 
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//AsyncSync/SyncContract]
    AUTHORIZATION dbo 
    ( [//AsyncSync/Customer] SENT BY ANY,
      [//AsyncSync/Product] SENT BY ANY,
      [//AsyncSync/Contact] SENT BY ANY
    )
GO

CREATE QUEUE SyncQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//AsyncSync/SyncService] 
AUTHORIZATION SyncUser 
ON QUEUE SyncQueue
([//AsyncSync/SyncContract])
GO

CREATE QUEUE SyncProcessQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//AsyncSync/SyncProcessSvc] 
AUTHORIZATION SyncUser 
ON QUEUE SyncProcessQueue
([//AsyncSync/SyncContract])
GO


-- Send a message

  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;
  DECLARE @ChangeMsg XML;
  DECLARE @ChangeCnt int;

      BEGIN DIALOG @InitDlgHandle
           FROM SERVICE [//AsyncSync/SyncService]
           TO SERVICE N'//AsyncSync/SyncProcessSvc'
           ON CONTRACT [//AsyncSync/SyncContract]
           WITH
               ENCRYPTION = ON;

        set @ChangeMsg = (
        SELECT TOP 1 c.[AccountNumber]
          FROM [Sales].[Customer] c
          FOR XML RAW, ELEMENTS, ROOT ('Customer')
          );

      BEGIN TRANSACTION;
      SEND ON CONVERSATION @InitDlgHandle
           MESSAGE TYPE [//AsyncSync/Customer]
           (@ChangeMsg);
      COMMIT TRANSACTION;
      END CONVERSATION @InitDlgHandle;

-- View the transmission queue
SELECT * FROM sys.transmission_queue
GO

-- View the created conversation endpoints
SELECT * FROM sys.conversation_endpoints
GO

-- See that it's there
  SELECT * from SyncProcessQueue
  
-- Now actually receive it
    DECLARE @ch UNIQUEIDENTIFIER
    DECLARE @messagetypename NVARCHAR(256),
        @service_name nvarchar(512),
        @service_contract_name NVARCHAR(256)
    DECLARE @messagebody XML

    WAITFOR (
        RECEIVE TOP(1)
            @ch = conversation_handle,
            @service_name = service_name,
            @service_contract_name = service_contract_name,
            @messagetypename = message_type_name,
            @messagebody = CAST(message_body AS XML)
        FROM SyncProcessQueue
    ), TIMEOUT 60000

    SELECT @messagebody

-- See that it's not there now
  SELECT * from SyncProcessQueue
  
