USE master
GO

SELECT d.is_master_key_encrypted_by_server
FROM sys.databases AS d
WHERE d.name = 'Northwind';  --Returns 0 before implementing the database master key
GO

USE Northwind
GO

CREATE MASTER KEY
       ENCRYPTION BY PASSWORD = N'XYJDn2SXHjceE5R98uu9Ts9G';
GO

CREATE USER NWSyncUser WITHOUT LOGIN;
GO
CREATE CERTIFICATE NWSyncCertificate 
     AUTHORIZATION NWSyncUser
     WITH SUBJECT = 'NWSync Certificate',
          EXPIRY_DATE = N'12/31/2040';

BACKUP CERTIFICATE NWSyncCertificate
  TO FILE = N'E:\Certs\NWSyncCertificate.cer';
GO

USE [MASTER] 
ALTER DATABASE [Northwind] SET NEW_BROKER
GO

USE Northwind
GO

CREATE MESSAGE TYPE [//NorthWindSync/SBETL]
AUTHORIZATION dbo
VALIDATION = WELL_FORMED_XML
GO

CREATE CONTRACT [//NorthWindSync/SyncContract]
	AUTHORIZATION dbo (
	[//NorthWindSync/SBETL] SENT BY ANY
	)
GO

CREATE QUEUE NWSyncQueue
   WITH 
   STATUS = ON,
   RETENTION = OFF 
GO

CREATE SERVICE [//NWSyncSite/NWSyncService] 
AUTHORIZATION NWSyncUser 
ON QUEUE NWSyncQueue
([//NorthWindSync/SyncContract])
GO

USE [master];
GO

IF EXISTS 
(SELECT * 
	FROM master.sys.endpoints
    WHERE name = N'INST01Endpoint')
    
	DROP ENDPOINT INST01Endpoint;
GO

CREATE ENDPOINT INST01Endpoint
STATE = STARTED
AS TCP ( LISTENER_PORT = 4022 )
FOR SERVICE_BROKER (AUTHENTICATION = WINDOWS );
GO
GRANT CONNECT ON ENDPOINT::[INST01Endpoint] to [SQLTBWS\sqlexec]
GO
