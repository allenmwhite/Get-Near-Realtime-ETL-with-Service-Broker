USE Northwind
GO

CREATE USER DWSyncUser WITHOUT LOGIN;

CREATE CERTIFICATE DWSyncCertificate
   AUTHORIZATION DWSyncUser
   FROM FILE = N'E:\Certs\DWSyncCertificate.cer';
GO

USE Northwind
GO

CREATE ROUTE DWSyncRoute 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'//DWSyncSite/DWSyncService',
     ADDRESS = N'TCP://SQLTBWS:4023'
GO

USE msdb;
GO

CREATE ROUTE NWSyncRoute 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'//NWSyncSite/NWSyncService',
     ADDRESS = N'LOCAL'
GO

USE Northwind
GO

CREATE REMOTE SERVICE BINDING [DWSyncBinding] 
  AUTHORIZATION dbo 
  TO SERVICE N'//DWSyncSite/DWSyncService'
  WITH USER = [DWSyncUser]
GO

GRANT SEND
      ON SERVICE::[//NWSyncSite/NWSyncService]
      TO DWSyncUser;
GO
