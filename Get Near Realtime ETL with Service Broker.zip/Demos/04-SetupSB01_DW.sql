USE NorthwindDW
GO

CREATE USER NWSyncUser WITHOUT LOGIN;

CREATE CERTIFICATE NWSyncCertificate 
   AUTHORIZATION NWSyncUser
   FROM FILE = N'E:\Certs\NWSyncCertificate.cer'
GO

USE NorthwindDW
GO

CREATE ROUTE NWSyncRoute 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'//NWSyncSite/NWSyncService',
     ADDRESS = N'TCP://SQLTBWS:4022'
GO

USE msdb;
GO

CREATE ROUTE DWSyncRoute 
AUTHORIZATION dbo 
WITH 
     SERVICE_NAME = N'//DWSyncSite/DWSyncService',
     ADDRESS = N'LOCAL'
GO

USE NorthwindDW
GO

CREATE REMOTE SERVICE BINDING [NWSyncBinding] 
  AUTHORIZATION dbo 
  TO SERVICE N'//NWSyncSite/NWSyncService'
  WITH USER = [NWSyncUser]
GO

GRANT SEND
      ON SERVICE::[//DWSyncSite/DWSyncService]
      TO NWSyncUser;
GO
