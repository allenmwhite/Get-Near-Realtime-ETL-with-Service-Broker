USE Northwind
GO

CREATE TABLE [dbo].[BrokerConversation]
(
	[ch] [uniqueidentifier] NULL,
	[service_name] [nvarchar] (512) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
)
GO
CREATE TABLE [dbo].[ErrorLog](
	[ErrorLogID] [int] IDENTITY(1,1) NOT NULL,
	[ErrorTime] [datetime] NOT NULL,
	[UserName] [sysname] NOT NULL,
	[ErrorNumber] [int] NOT NULL,
	[ErrorSeverity] [int] NULL,
	[ErrorState] [int] NULL,
	[ErrorProcedure] [nvarchar](126) NULL,
	[ErrorLine] [int] NULL,
	[ErrorMessage] [nvarchar](4000) NOT NULL,
 CONSTRAINT [PK_ErrorLog_ErrorLogID] PRIMARY KEY CLUSTERED 
(
	[ErrorLogID] ASC
)
) ON [PRIMARY]

GO
IF OBJECT_ID ('dbo.StartETLConversation','P') IS NOT NULL
   DROP PROCEDURE dbo.StartETLConversation
GO
CREATE PROC [dbo].[StartETLConversation]
AS
SET NOCOUNT ON;

    DECLARE @ch UNIQUEIDENTIFIER;
    DECLARE @service_name nvarchar(512) = N'//NWSyncSite/NWSyncService';
    
    SELECT @ch=[ch]
    FROM [dbo].[BrokerConversation]
    WHERE [service_name] = @service_name;
    
    IF @ch IS NOT NULL
        BEGIN
        DELETE FROM [dbo].[BrokerConversation]
        WHERE [service_name] = @service_name;
        
        END CONVERSATION @ch;
        END

    BEGIN DIALOG @ch
       FROM SERVICE [//NWSyncSite/NWSyncService]
       TO SERVICE N'//DWSyncSite/DWSyncService'
       ON CONTRACT [//NorthWindSync/SyncContract]
       WITH
           ENCRYPTION = ON;

    INSERT INTO [dbo].[BrokerConversation]
        (ch, service_name)
    VALUES (@ch, @service_name);

GO
