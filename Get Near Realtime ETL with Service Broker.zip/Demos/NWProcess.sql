CREATE TABLE #Categories (
	[Action] nchar(1) NULL,
	[CategoryID]  Int NULL,
	[CategoryName]  NVarChar(15) NULL,
	[CategoryDescription]  NVarChar(250) NULL
	)
INSERT INTO #Categories
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
	a.value(N'(./CategoryName)[1]', N'NVarChar(15)') as [CategoryName],
	a.value(N'(./CategoryDescription)[1]', N'NVarChar(250)') as [CategoryDescription]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Customers (
	[Action] nchar(1) NULL,
	[CustomerID]  NChar(5) NULL,
	[CompanyName]  NVarChar(40) NULL,
	[ContactName]  NVarChar(30) NULL,
	[ContactTitle]  NVarChar(30) NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
INSERT INTO #Customers
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./ContactName)[1]', N'NVarChar(30)') as [ContactName],
	a.value(N'(./ContactTitle)[1]', N'NVarChar(30)') as [ContactTitle],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Employees (
	[Action] nchar(1) NULL,
	[EmployeeID]  Int NULL,
	[LastName]  NVarChar(20) NULL,
	[FirstName]  NVarChar(10) NULL,
	[Title]  NVarChar(30) NULL,
	[TitleOfCourtesy]  NVarChar(25) NULL,
	[BirthDate]  DateTime NULL,
	[HireDate]  DateTime NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[HomePhone]  NVarChar(24) NULL,
	[Extension]  NVarChar(4) NULL
	)
INSERT INTO #Employees
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./LastName)[1]', N'NVarChar(20)') as [LastName],
	a.value(N'(./FirstName)[1]', N'NVarChar(10)') as [FirstName],
	a.value(N'(./Title)[1]', N'NVarChar(30)') as [Title],
	a.value(N'(./TitleOfCourtesy)[1]', N'NVarChar(25)') as [TitleOfCourtesy],
	a.value(N'(./BirthDate)[1]', N'DateTime') as [BirthDate],
	a.value(N'(./HireDate)[1]', N'DateTime') as [HireDate],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./HomePhone)[1]', N'NVarChar(24)') as [HomePhone],
	a.value(N'(./Extension)[1]', N'NVarChar(4)') as [Extension]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #OrderDetails (
	[Action] nchar(1) NULL,
	[OrderDetailID]  Int NULL,
	[OrderID]  Int NULL,
	[ProductID]  Int NULL,
	[UnitPrice]  Money NULL,
	[Quantity]  SmallInt NULL,
	[Discount]  Real NULL
	)
INSERT INTO #OrderDetails
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderDetailID)[1]', N'Int') as [OrderDetailID],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./Quantity)[1]', N'SmallInt') as [Quantity],
	a.value(N'(./Discount)[1]', N'Real') as [Discount]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Orders (
	[Action] nchar(1) NULL,
	[OrderID]  Int NULL,
	[CustomerID]  NChar(5) NULL,
	[EmployeeID]  Int NULL,
	[OrderDate]  DateTime NULL,
	[RequiredDate]  DateTime NULL,
	[ShippedDate]  DateTime NULL,
	[ShipVia]  Int NULL,
	[Freight]  Money NULL,
	[ShipName]  NVarChar(40) NULL,
	[ShipAddress]  NVarChar(60) NULL,
	[ShipCity]  NVarChar(15) NULL,
	[ShipRegion]  NVarChar(15) NULL,
	[ShipPostalCode]  NVarChar(10) NULL,
	[ShipCountry]  NVarChar(15) NULL
	)
INSERT INTO #Orders
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./OrderDate)[1]', N'DateTime') as [OrderDate],
	a.value(N'(./RequiredDate)[1]', N'DateTime') as [RequiredDate],
	a.value(N'(./ShippedDate)[1]', N'DateTime') as [ShippedDate],
	a.value(N'(./ShipVia)[1]', N'Int') as [ShipVia],
	a.value(N'(./Freight)[1]', N'Money') as [Freight],
	a.value(N'(./ShipName)[1]', N'NVarChar(40)') as [ShipName],
	a.value(N'(./ShipAddress)[1]', N'NVarChar(60)') as [ShipAddress],
	a.value(N'(./ShipCity)[1]', N'NVarChar(15)') as [ShipCity],
	a.value(N'(./ShipRegion)[1]', N'NVarChar(15)') as [ShipRegion],
	a.value(N'(./ShipPostalCode)[1]', N'NVarChar(10)') as [ShipPostalCode],
	a.value(N'(./ShipCountry)[1]', N'NVarChar(15)') as [ShipCountry]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Products (
	[Action] nchar(1) NULL,
	[ProductID]  Int NULL,
	[ProductName]  NVarChar(40) NULL,
	[SupplierID]  Int NULL,
	[CategoryID]  Int NULL,
	[QuantityPerUnit]  NVarChar(20) NULL,
	[UnitPrice]  Money NULL,
	[UnitsInStock]  SmallInt NULL,
	[UnitsOnOrder]  SmallInt NULL,
	[ReorderLevel]  SmallInt NULL,
	[Discontinued]  Bit NULL
	)
INSERT INTO #Products
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./ProductName)[1]', N'NVarChar(40)') as [ProductName],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./CategoryID)[1]', N'Int') as [CategoryID],
	a.value(N'(./QuantityPerUnit)[1]', N'NVarChar(20)') as [QuantityPerUnit],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./UnitsInStock)[1]', N'SmallInt') as [UnitsInStock],
	a.value(N'(./UnitsOnOrder)[1]', N'SmallInt') as [UnitsOnOrder],
	a.value(N'(./ReorderLevel)[1]', N'SmallInt') as [ReorderLevel],
	a.value(N'(./Discontinued)[1]', N'Bit') as [Discontinued]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Shippers (
	[Action] nchar(1) NULL,
	[ShipperID]  Int NULL,
	[CompanyName]  NVarChar(40) NULL,
	[Phone]  NVarChar(24) NULL
	)
INSERT INTO #Shippers
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ShipperID)[1]', N'Int') as [ShipperID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone]
	from @messagebody.nodes('/SBETL/row') as r(a);'

CREATE TABLE #Suppliers (
	[Action] nchar(1) NULL,
	[SupplierID]  Int NULL,
	[SupplierCompanyName]  NVarChar(40) NULL,
	[SupplierContactName]  NVarChar(30) NULL,
	[SupplierContactTitle]  NVarChar(30) NULL,
	[SupplierAddress]  NVarChar(60) NULL,
	[SupplierCity]  NVarChar(15) NULL,
	[SupplierRegion]  NVarChar(15) NULL,
	[SupplierPostalCode]  NVarChar(10) NULL,
	[SupplierCountry]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
INSERT INTO #Suppliers
SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./SupplierCompanyName)[1]', N'NVarChar(40)') as [SupplierCompanyName],
	a.value(N'(./SupplierContactName)[1]', N'NVarChar(30)') as [SupplierContactName],
	a.value(N'(./SupplierContactTitle)[1]', N'NVarChar(30)') as [SupplierContactTitle],
	a.value(N'(./SupplierAddress)[1]', N'NVarChar(60)') as [SupplierAddress],
	a.value(N'(./SupplierCity)[1]', N'NVarChar(15)') as [SupplierCity],
	a.value(N'(./SupplierRegion)[1]', N'NVarChar(15)') as [SupplierRegion],
	a.value(N'(./SupplierPostalCode)[1]', N'NVarChar(10)') as [SupplierPostalCode],
	a.value(N'(./SupplierCountry)[1]', N'NVarChar(15)') as [SupplierCountry],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/SBETL/row') as r(a);'
