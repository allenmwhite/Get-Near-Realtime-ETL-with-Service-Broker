USE [master]
GO
CREATE DATABASE [NorthwindDW]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'NorthwindDW', FILENAME = N'E:\MSSQL\MSSQL14.INST02\MSSQL\DATA\NorthwindDW.mdf' , SIZE = 30720KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'NorthwindDW_log', FILENAME = N'F:\MSSQL\MSSQL14.INST02\MSSQL\DATA\NorthwindDW_log.ldf' , SIZE = 10240KB , MAXSIZE = 2048GB , FILEGROWTH = 1024KB)
GO

USE [NorthwindDW]
GO

CREATE SCHEMA [Reference]
GO

CREATE TABLE [dbo].[dimProducts](
	[ProductSK] [int] IDENTITY(1,1) NOT NULL,
	[ProductID] [int] NOT NULL,
	[ProductName] [nvarchar](40) NOT NULL,
	[SupplierID] [int] NULL,
	[SupplierCompanyName] [nvarchar](40) NULL,
	[SupplierContactName] [nvarchar](30) NULL,
	[SupplierContactTitle] [nvarchar](30) NULL,
	[SupplierAddress] [nvarchar](60) NULL,
	[SupplierCity] [nvarchar](15) NULL,
	[SupplierRegion] [nvarchar](15) NULL,
	[SupplierPostalCode] [nvarchar](10) NULL,
	[SupplierCountry] [nvarchar](15) NULL,
	[CategoryID] [int] NULL,
	[CategoryName] [nvarchar](15) NULL,
	[CategoryDescription] [nvarchar](250)NULL,
	[QuantityPerUnit] [nvarchar](20) NULL,
	[UnitPrice] [money] NULL,
	[ProductStartDate] [smalldatetime] NULL,
	[ProductEndDate] [smalldatetime] NULL,
 CONSTRAINT [PK_dimProducts] PRIMARY KEY CLUSTERED 
(
	[ProductSK] ASC
)
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[dimCustomers](
	[CustomerSK] [int] IDENTITY(1,1) NOT NULL,
	[CustomerID] [nchar](5) NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ContactName] [nvarchar](30) NULL,
	[ContactTitle] [nvarchar](30) NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[CustomerStartDate] [smalldatetime] NULL,
	[CustomerEndDate] [smalldatetime] NULL,
 CONSTRAINT [PK_dimCustomers] PRIMARY KEY CLUSTERED 
(
	[CustomerSK] ASC
)
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[dimEmployees](
	[EmployeeSK] [int] IDENTITY(1,1) NOT NULL,
	[EmployeeID] [int] NOT NULL,
	[LastName] [nvarchar](20) NOT NULL,
	[FirstName] [nvarchar](10) NOT NULL,
	[Title] [nvarchar](30) NULL,
	[TitleOfCourtesy] [nvarchar](25) NULL,
	[BirthDate] [datetime] NULL,
	[HireDate] [datetime] NULL,
	[Address] [nvarchar](60) NULL,
	[City] [nvarchar](15) NULL,
	[Region] [nvarchar](15) NULL,
	[PostalCode] [nvarchar](10) NULL,
	[Country] [nvarchar](15) NULL,
	[EmployeeStartDate] [smalldatetime] NULL,
	[EmployeeEndDate] [smalldatetime] NULL,
 CONSTRAINT [PK_dimEmployees] PRIMARY KEY CLUSTERED 
(
	[EmployeeSK] ASC
)
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[dimShippers](
	[ShipperSK] [int] IDENTITY(1,1) NOT NULL,
	[ShipperID] [int] NOT NULL,
	[CompanyName] [nvarchar](40) NOT NULL,
	[ShipperStartDate] [smalldatetime] NULL,
	[ShipperEndDate] [smalldatetime] NULL,
 CONSTRAINT [PK_dimShippers] PRIMARY KEY CLUSTERED 
(
	[ShipperSK] ASC
)
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[factOrders](
	[OrderSK] [int] IDENTITY(1,1) NOT NULL,
	[OrderDetailID] [int] NOT NULL,
	[OrderID] [int] NULL,
	[ProductSK] [int] NULL,
	[CustomerSK] [int] NULL,
	[EmployeeSK] [int] NULL,
	[ShipperSK] [int] NULL,
	[OrderDate] [datetime] NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,
	[Freight] [money] NULL,
	[UnitPrice] [money] NULL,
	[Quantity] [smallint] NULL,
	[Discount] [real] NULL,
 CONSTRAINT [PK_factOrders] PRIMARY KEY CLUSTERED 
(
	[OrderSK] ASC
)
) ON [PRIMARY]

GO

CREATE TABLE [Reference].[Categories](
	[CategoryID] [int] NOT NULL,
	[CategoryName] [nvarchar](15) NULL,
	[CategoryDescription] [nvarchar](250) NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[CategoryID] ASC
)
) ON [PRIMARY]
GO
CREATE TABLE [Reference].[Suppliers](
	[SupplierID] [int] NOT NULL,
	[SupplierCompanyName] [nvarchar](40) NULL,
	[SupplierContactName] [nvarchar](30) NULL,
	[SupplierContactTitle] [nvarchar](30) NULL,
	[SupplierAddress] [nvarchar](60) NULL,
	[SupplierCity] [nvarchar](15) NULL,
	[SupplierRegion] [nvarchar](15) NULL,
	[SupplierPostalCode] [nvarchar](10) NULL,
	[SupplierCountry] [nvarchar](15) NULL,
	[Phone] [nvarchar](24) NULL,
	[Fax] [nvarchar](24) NULL,
 CONSTRAINT [PK_Suppliers] PRIMARY KEY CLUSTERED 
(
	[SupplierID] ASC
)
) ON [PRIMARY]
GO

CREATE TABLE [Reference].[Orders](
	[OrderID] [int] NOT NULL,
	[CustomerID] [nchar](5) NULL,
	[EmployeeID] [int] NULL,
	[OrderDate] [datetime] NULL,
	[RequiredDate] [datetime] NULL,
	[ShippedDate] [datetime] NULL,
	[ShipVia] [int] NULL,
	[Freight] [money] NULL,
	[ShipName] [nvarchar](40) NULL,
	[ShipAddress] [nvarchar](60) NULL,
	[ShipCity] [nvarchar](15) NULL,
	[ShipRegion] [nvarchar](15) NULL,
	[ShipPostalCode] [nvarchar](10) NULL,
	[ShipCountry] [nvarchar](15) NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
(
	[OrderID] ASC
)
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[factOrders]  WITH NOCHECK ADD  CONSTRAINT [FK_factOrders_dimProducts] FOREIGN KEY([ProductSK])
REFERENCES [dbo].[dimProducts] ([ProductSK])
GO
ALTER TABLE [dbo].[factOrders] CHECK CONSTRAINT [FK_factOrders_dimProducts]
GO
ALTER TABLE [dbo].[factOrders]  WITH NOCHECK ADD  CONSTRAINT [FK_factOrders_dimCustomers] FOREIGN KEY([CustomerSK])
REFERENCES [dbo].[dimCustomers] ([CustomerSK])
GO
ALTER TABLE [dbo].[factOrders] CHECK CONSTRAINT [FK_factOrders_dimCustomers]
GO
ALTER TABLE [dbo].[factOrders]  WITH NOCHECK ADD  CONSTRAINT [FK_factOrders_dimEmployees] FOREIGN KEY([EmployeeSK])
REFERENCES [dbo].[dimEmployees] ([EmployeeSK])
GO
ALTER TABLE [dbo].[factOrders] CHECK CONSTRAINT [FK_factOrders_dimEmployees]
GO
ALTER TABLE [dbo].[factOrders]  WITH NOCHECK ADD  CONSTRAINT [FK_factOrders_dimShippers] FOREIGN KEY([ShipperSK])
REFERENCES [dbo].[dimShippers] ([ShipperSK])
GO
ALTER TABLE [dbo].[factOrders] CHECK CONSTRAINT [FK_factOrders_dimShippers]
GO

USE [NorthwindDW]
GO

SET IDENTITY_INSERT [dbo].[dimCustomers] ON
GO
INSERT INTO [dbo].[dimCustomers]
           ([CustomerSK]
           ,[CustomerID]
           ,[CompanyName]
           ,[CustomerStartDate]
           ,[CustomerEndDate])
     VALUES
           (-1
           ,'NONE'
           ,'Unknown'
           ,'1901-01-01'
           ,NULL)
GO
SET IDENTITY_INSERT [dbo].[dimCustomers] OFF
GO
SET IDENTITY_INSERT [dbo].[dimEmployees] ON
GO
INSERT INTO [dbo].[dimEmployees]
           ([EmployeeSK]
           ,[EmployeeID]
           ,[LastName]
           ,[FirstName]
           ,[EmployeeStartDate]
           ,[EmployeeEndDate])
     VALUES
           (-1
           ,0
           ,'Unknown'
           ,'Unknown'
           ,'1901-01-01'
           ,NULL)
GO
SET IDENTITY_INSERT [dbo].[dimEmployees] OFF
GO
SET IDENTITY_INSERT [dbo].[dimProducts] ON
GO
INSERT INTO [dbo].[dimProducts]
           ([ProductSK]
           ,[ProductID]
           ,[ProductName]
           ,[ProductStartDate]
           ,[ProductEndDate])
     VALUES
           (-1
           ,0
           ,'Unknown'
           ,'1901-01-01'
           ,NULL)
GO
SET IDENTITY_INSERT [dbo].[dimProducts] OFF
GO
SET IDENTITY_INSERT [dbo].[dimShippers] ON
GO
INSERT INTO [dbo].[dimShippers]
           ([ShipperSK]
           ,[ShipperID]
           ,[CompanyName]
           ,[ShipperStartDate]
           ,[ShipperEndDate])
     VALUES
           (-1
           ,0
           ,'Unknown'
           ,'1901-01-01'
           ,NULL)
GO
SET IDENTITY_INSERT [dbo].[dimShippers] OFF
GO

