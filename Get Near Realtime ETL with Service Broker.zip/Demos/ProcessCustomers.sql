USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessCustomers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessCustomers]
GO

CREATE PROCEDURE [dbo].[ProcessCustomers]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Customers (
	[Action] nchar(1) NULL,
	[CustomerID]  NChar(5) NULL,
	[CompanyName]  NVarChar(40) NULL,
	[ContactName]  NVarChar(30) NULL,
	[ContactTitle]  NVarChar(30) NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Customers
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./ContactName)[1]', N'NVarChar(30)') as [ContactName],
	a.value(N'(./ContactTitle)[1]', N'NVarChar(30)') as [ContactTitle],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    UPDATE s
      SET s.[CustomerEndDate] = GETDATE()
    FROM [dbo].[dimCustomers] s
    INNER JOIN #Customers t ON s.[CustomerID] = t.[CustomerID]
      WHERE s.[CustomerEndDate] IS NULL
    
    DELETE FROM #Customers
      WHERE [Action] = 'D'
    
    INSERT INTO [dbo].[dimCustomers]
               ([CustomerID]
               ,[CompanyName]
               ,[ContactName]
               ,[ContactTitle]
               ,[Address]
               ,[City]
               ,[Region]
               ,[PostalCode]
               ,[Country]
               ,[CustomerStartDate]
               ,[CustomerEndDate])
    SELECT [CustomerID]
          ,[CompanyName]
          ,[ContactName]
          ,[ContactTitle]
          ,[Address]
          ,[City]
          ,[Region]
          ,[PostalCode]
          ,[Country]
          ,GETDATE() AS [CustomerStartDate]
          ,NULL AS [CustomerEndDate]
    FROM #Customers

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
