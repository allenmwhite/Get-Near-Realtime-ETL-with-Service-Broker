USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessEmployees]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessEmployees]
GO

CREATE PROCEDURE [dbo].[ProcessEmployees]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Employees (
	[Action] nchar(1) NULL,
	[EmployeeID]  Int NULL,
	[LastName]  NVarChar(20) NULL,
	[FirstName]  NVarChar(10) NULL,
	[Title]  NVarChar(30) NULL,
	[TitleOfCourtesy]  NVarChar(25) NULL,
	[BirthDate]  DateTime NULL,
	[HireDate]  DateTime NULL,
	[Address]  NVarChar(60) NULL,
	[City]  NVarChar(15) NULL,
	[Region]  NVarChar(15) NULL,
	[PostalCode]  NVarChar(10) NULL,
	[Country]  NVarChar(15) NULL,
	[HomePhone]  NVarChar(24) NULL,
	[Extension]  NVarChar(4) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Employees
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./LastName)[1]', N'NVarChar(20)') as [LastName],
	a.value(N'(./FirstName)[1]', N'NVarChar(10)') as [FirstName],
	a.value(N'(./Title)[1]', N'NVarChar(30)') as [Title],
	a.value(N'(./TitleOfCourtesy)[1]', N'NVarChar(25)') as [TitleOfCourtesy],
	a.value(N'(./BirthDate)[1]', N'DateTime') as [BirthDate],
	a.value(N'(./HireDate)[1]', N'DateTime') as [HireDate],
	a.value(N'(./Address)[1]', N'NVarChar(60)') as [Address],
	a.value(N'(./City)[1]', N'NVarChar(15)') as [City],
	a.value(N'(./Region)[1]', N'NVarChar(15)') as [Region],
	a.value(N'(./PostalCode)[1]', N'NVarChar(10)') as [PostalCode],
	a.value(N'(./Country)[1]', N'NVarChar(15)') as [Country],
	a.value(N'(./HomePhone)[1]', N'NVarChar(24)') as [HomePhone],
	a.value(N'(./Extension)[1]', N'NVarChar(4)') as [Extension]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    UPDATE s
      SET s.[EmployeeEndDate] = GETDATE()
    FROM [dbo].[dimEmployees] s
    INNER JOIN #Employees t ON s.[EmployeeID] = t.[EmployeeID]
      WHERE s.[EmployeeEndDate] IS NULL
    
    DELETE FROM #Employees
      WHERE [Action] = 'D'
    
    INSERT INTO [dbo].[dimEmployees]
           ([EmployeeID]
           ,[LastName]
           ,[FirstName]
           ,[Title]
           ,[TitleOfCourtesy]
           ,[BirthDate]
           ,[HireDate]
           ,[Address]
           ,[City]
           ,[Region]
           ,[PostalCode]
           ,[Country]
           ,[EmployeeStartDate]
           ,[EmployeeEndDate])
    SELECT [EmployeeID]
      ,[LastName]
      ,[FirstName]
      ,[Title]
      ,[TitleOfCourtesy]
      ,[BirthDate]
      ,[HireDate]
      ,[Address]
      ,[City]
      ,[Region]
      ,[PostalCode]
      ,[Country]
      ,GETDATE() AS [EmployeeStartDate]
      ,NULL AS [EmployeeEndDate]
    FROM #Employees

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
