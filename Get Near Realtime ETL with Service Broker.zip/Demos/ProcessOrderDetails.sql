USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessOrderDetails]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessOrderDetails]
GO

CREATE PROCEDURE [dbo].[ProcessOrderDetails]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #OrderDetails (
	[Action] nchar(1) NULL,
	[OrderDetailID]  Int NULL,
	[OrderID]  Int NULL,
	[ProductID]  Int NULL,
	[UnitPrice]  Money NULL,
	[Quantity]  SmallInt NULL,
	[Discount]  Real NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #OrderDetails
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderDetailID)[1]', N'Int') as [OrderDetailID],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./ProductID)[1]', N'Int') as [ProductID],
	a.value(N'(./UnitPrice)[1]', N'Money') as [UnitPrice],
	a.value(N'(./Quantity)[1]', N'SmallInt') as [Quantity],
	a.value(N'(./Discount)[1]', N'Real') as [Discount]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    DELETE cs
    FROM [dbo].[factOrders] cs
    INNER JOIN #OrderDetails t ON cs.[OrderDetailID] = t.[OrderDetailID]
    
    DELETE
    FROM #OrderDetails
    WHERE [Action] = 'D'

    INSERT INTO [dbo].[factOrders]
           ([OrderDetailID]
           ,[OrderID]
           ,[ProductSK]
           ,[CustomerSK]
           ,[EmployeeSK]
           ,[ShipperSK]
           ,[OrderDate]
           ,[RequiredDate]
           ,[ShippedDate]
           ,[Freight]
           ,[UnitPrice]
           ,[Quantity]
           ,[Discount])
    SELECT od.[OrderDetailID]
      ,od.[OrderID]
      ,[ProductSK] = CASE WHEN p.ProductID IS NULL THEN -1 ELSE p.ProductSK END
      ,[CustomerSK] = CASE WHEN c.CustomerID IS NULL THEN -1 ELSE c.CustomerSK END
      ,[EmployeeSK] = CASE WHEN e.EmployeeID IS NULL THEN -1 ELSE e.EmployeeSK END
      ,[ShipperSK] = CASE WHEN s.ShipperID IS NULL THEN -1 ELSE s.ShipperSK END
      ,o.[OrderDate]
      ,o.[RequiredDate]
      ,o.[ShippedDate]
      ,o.[Freight]
      ,od.[UnitPrice]
      ,od.[Quantity]
      ,od.[Discount]
    FROM #OrderDetails od
    LEFT JOIN [Reference].[Orders] o ON od.[OrderID] = o.[OrderID]
    LEFT JOIN [dbo].[dimProducts] p ON od.[ProductID] = p.[ProductID]
    	AND p.[ProductEndDate] IS NULL
    LEFT JOIN [dbo].[dimCustomers] c ON o.[CustomerID] = c.[CustomerID]
    	AND c.[CustomerEndDate] IS NULL
    LEFT JOIN [dbo].[dimEmployees] e ON o.[EmployeeID] = e.[EmployeeID]
    	AND e.[EmployeeEndDate] IS NULL
    LEFT JOIN [dbo].[dimShippers] s ON o.[ShipVia] = s.[ShipperID]
    	AND s.[ShipperEndDate] IS NULL

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
