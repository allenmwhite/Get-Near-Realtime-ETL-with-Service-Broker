USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessOrders]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessOrders]
GO

CREATE PROCEDURE [dbo].[ProcessOrders]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Orders (
	[Action] nchar(1) NULL,
	[OrderID]  Int NULL,
	[CustomerID]  NChar(5) NULL,
	[EmployeeID]  Int NULL,
	[OrderDate]  DateTime NULL,
	[RequiredDate]  DateTime NULL,
	[ShippedDate]  DateTime NULL,
	[ShipVia]  Int NULL,
	[Freight]  Money NULL,
	[ShipName]  NVarChar(40) NULL,
	[ShipAddress]  NVarChar(60) NULL,
	[ShipCity]  NVarChar(15) NULL,
	[ShipRegion]  NVarChar(15) NULL,
	[ShipPostalCode]  NVarChar(10) NULL,
	[ShipCountry]  NVarChar(15) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Orders
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./OrderID)[1]', N'Int') as [OrderID],
	a.value(N'(./CustomerID)[1]', N'NChar(5)') as [CustomerID],
	a.value(N'(./EmployeeID)[1]', N'Int') as [EmployeeID],
	a.value(N'(./OrderDate)[1]', N'DateTime') as [OrderDate],
	a.value(N'(./RequiredDate)[1]', N'DateTime') as [RequiredDate],
	a.value(N'(./ShippedDate)[1]', N'DateTime') as [ShippedDate],
	a.value(N'(./ShipVia)[1]', N'Int') as [ShipVia],
	a.value(N'(./Freight)[1]', N'Money') as [Freight],
	a.value(N'(./ShipName)[1]', N'NVarChar(40)') as [ShipName],
	a.value(N'(./ShipAddress)[1]', N'NVarChar(60)') as [ShipAddress],
	a.value(N'(./ShipCity)[1]', N'NVarChar(15)') as [ShipCity],
	a.value(N'(./ShipRegion)[1]', N'NVarChar(15)') as [ShipRegion],
	a.value(N'(./ShipPostalCode)[1]', N'NVarChar(10)') as [ShipPostalCode],
	a.value(N'(./ShipCountry)[1]', N'NVarChar(15)') as [ShipCountry]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    DELETE cs
    FROM [Reference].[Orders] cs
    INNER JOIN #Orders t ON cs.[OrderID] = t.[OrderID]
    
    DELETE
    FROM #Orders
    WHERE [Action] = 'D'

    INSERT INTO [Reference].[Orders]
           ([OrderID]
           ,[CustomerID]
           ,[EmployeeID]
           ,[OrderDate]
           ,[RequiredDate]
           ,[ShippedDate]
           ,[ShipVia]
           ,[Freight]
           ,[ShipName]
           ,[ShipAddress]
           ,[ShipCity]
           ,[ShipRegion]
           ,[ShipPostalCode]
           ,[ShipCountry])
    SELECT [OrderID]
      ,[CustomerID]
      ,[EmployeeID]
      ,[OrderDate]
      ,[RequiredDate]
      ,[ShippedDate]
      ,[ShipVia]
      ,[Freight]
      ,[ShipName]
      ,[ShipAddress]
      ,[ShipCity]
      ,[ShipRegion]
      ,[ShipPostalCode]
      ,[ShipCountry]
    FROM #Orders

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
