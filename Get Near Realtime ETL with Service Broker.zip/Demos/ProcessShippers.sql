USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessShippers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessShippers]
GO

CREATE PROCEDURE [dbo].[ProcessShippers]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Shippers (
	[Action] nchar(1) NULL,
	[ShipperID]  Int NULL,
	[CompanyName]  NVarChar(40) NULL,
	[Phone]  NVarChar(24) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Shippers
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./ShipperID)[1]', N'Int') as [ShipperID],
	a.value(N'(./CompanyName)[1]', N'NVarChar(40)') as [CompanyName],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    UPDATE s
      SET s.[ShipperEndDate] = GETDATE()
    FROM [dbo].[dimShippers] s
    INNER JOIN #Shippers t ON s.[ShipperID] = t.[ShipperID]
      WHERE s.[ShipperEndDate] IS NULL
    
    DELETE FROM #Shippers
      WHERE [Action] = 'D'

    INSERT INTO [dbo].[dimShippers]
           ([ShipperID]
           ,[CompanyName]
           ,[ShipperStartDate]
           ,[ShipperEndDate])
    SELECT [ShipperID]
      ,[CompanyName]
      ,GETDATE() AS [ShipperStartDate]
      ,NULL AS [ShipperEndDate]
    FROM #Shippers

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
