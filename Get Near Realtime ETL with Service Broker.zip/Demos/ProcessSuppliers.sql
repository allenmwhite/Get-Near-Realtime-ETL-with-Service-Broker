USE [NorthwindDW]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSuppliers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[ProcessSuppliers]
GO

CREATE PROCEDURE [dbo].[ProcessSuppliers]
	@messagebody XML
WITH EXECUTE AS 'NWSyncUser'
AS
  SET NOCOUNT ON
  BEGIN TRY
  
    -- Create a temporary table to hold the message results
    CREATE TABLE #Suppliers (
	[Action] nchar(1) NULL,
	[SupplierID]  Int NULL,
	[SupplierCompanyName]  NVarChar(40) NULL,
	[SupplierContactName]  NVarChar(30) NULL,
	[SupplierContactTitle]  NVarChar(30) NULL,
	[SupplierAddress]  NVarChar(60) NULL,
	[SupplierCity]  NVarChar(15) NULL,
	[SupplierRegion]  NVarChar(15) NULL,
	[SupplierPostalCode]  NVarChar(10) NULL,
	[SupplierCountry]  NVarChar(15) NULL,
	[Phone]  NVarChar(24) NULL,
	[Fax]  NVarChar(24) NULL
	)
    
    -- Use XQuery to shred the message and insert it into the temporary table
    INSERT INTO #Suppliers
    SELECT
	a.value(N'(./Action)[1]', N'nchar(1)') as [Action],
	a.value(N'(./SupplierID)[1]', N'Int') as [SupplierID],
	a.value(N'(./SupplierCompanyName)[1]', N'NVarChar(40)') as [SupplierCompanyName],
	a.value(N'(./SupplierContactName)[1]', N'NVarChar(30)') as [SupplierContactName],
	a.value(N'(./SupplierContactTitle)[1]', N'NVarChar(30)') as [SupplierContactTitle],
	a.value(N'(./SupplierAddress)[1]', N'NVarChar(60)') as [SupplierAddress],
	a.value(N'(./SupplierCity)[1]', N'NVarChar(15)') as [SupplierCity],
	a.value(N'(./SupplierRegion)[1]', N'NVarChar(15)') as [SupplierRegion],
	a.value(N'(./SupplierPostalCode)[1]', N'NVarChar(10)') as [SupplierPostalCode],
	a.value(N'(./SupplierCountry)[1]', N'NVarChar(15)') as [SupplierCountry],
	a.value(N'(./Phone)[1]', N'NVarChar(24)') as [Phone],
	a.value(N'(./Fax)[1]', N'NVarChar(24)') as [Fax]
	from @messagebody.nodes('/SBETL/row') as r(a);
    
    -- Insert or Update the rows based on the incoming changes

    DELETE cs
    FROM [Reference].[Suppliers] cs
    INNER JOIN #Suppliers t ON cs.[SupplierID] = t.[SupplierID]
    
    DELETE
    FROM #Suppliers
    WHERE [Action] = 'D'

    INSERT INTO [Reference].[Suppliers]
           ([SupplierID]
           ,[SupplierCompanyName]
           ,[SupplierContactName]
           ,[SupplierContactTitle]
           ,[SupplierAddress]
           ,[SupplierCity]
           ,[SupplierRegion]
           ,[SupplierPostalCode]
           ,[SupplierCountry]
           ,[Phone]
           ,[Fax])
    SELECT [SupplierID]
      ,[SupplierCompanyName]
      ,[SupplierContactName]
      ,[SupplierContactTitle]
      ,[SupplierAddress]
      ,[SupplierCity]
      ,[SupplierRegion]
      ,[SupplierPostalCode]
      ,[SupplierCountry]
      ,[Phone]
      ,[Fax]
    FROM #Suppliers

  END TRY

  BEGIN CATCH
    -- Insert any errors into the ErrorLog table for later review and correction
    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,
    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)
    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),
    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)
  
  END CATCH

  RETURN

GO
