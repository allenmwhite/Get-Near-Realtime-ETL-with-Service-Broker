$svr = New-Object Microsoft.SqlServer.Management.Smo.Server WS12SQL
$dbnm = 'CentinelTest_MPI'
$db = $svr.Databases[$dbnm]
$ddl = [string] ''	# This variable will contain the code for the Process table stored procedures
$trg = [string] ''	# This variable will contain the code for the source database triggers
$psd = [string] ''	# This variable will contain the code for the ProcessSyncData stored procedure
$syncusr = "$($dbnm)SyncUser"

# Build the opening Transact-SQL for the ProcessSyncData stored procedure
$psd += "IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ProcessSyncData]') AND type in (N'P', N'PC'))`r`n"
$psd += "DROP PROCEDURE [dbo].[ProcessSyncData]`r`n"
$psd += "GO`r`n"
$psd += "`r`n"
$psd += "CREATE PROCEDURE [dbo].[ProcessSyncData]`r`n"
$psd += "AS`r`n"
$psd += "SET NOCOUNT ON`r`n"
$psd += "    DECLARE @id INT;`r`n"
$psd += "    DECLARE @ch UNIQUEIDENTIFIER`r`n"
$psd += "    DECLARE @messagetypename NVARCHAR(256)`r`n"
$psd += "    DECLARE @messagebody XML`r`n"
$psd += "    DECLARE @responsemessage XML;`r`n"
$psd += "    DECLARE @returnrows INT;`r`n"
$psd += "`r`n"
$psd += "    WHILE (1=1)`r`n"
$psd += "    BEGIN`r`n"
$psd += "        BEGIN TRY`r`n"
$psd += "`r`n"
$psd += "            SELECT TOP 1 @id=id, @ch=ch, @messagetypename=messagetypename, @messagebody=messagebody`r`n"
$psd += "            FROM [dbo].[BrokerMessages]`r`n"
$psd += "            ORDER BY id;`r`n"
$psd += "            SELECT @returnrows = @@ROWCOUNT`r`n"
$psd += "`r`n"
$psd += "            IF (@returnrows > 0)`r`n"
$psd += "            BEGIN`r`n"
$psd += "`r`n"
$psd += "                -- First extract the name of the table from the top row of the message`r`n"
$psd += "                DECLARE @TableName varchar(100);`r`n"
$psd += "                DECLARE @ETLTable TABLE (TableName varchar(100));`r`n"
$psd += "`r`n"
$psd += "                INSERT INTO @ETLTable (TableName)`r`n"
$psd += "                select TOP 1 a.value(N'(./TableName)[1]', N'varchar(100)') as TableName`r`n"
$psd += "                from @messagebody.nodes('/$dbnm/row') as r(a);`r`n"
$psd += "`r`n"
$psd += "                SELECT @TableName = TableName FROM @ETLTable;`r`n"
$psd += "`r`n"
$psd += "                -- Now call the procedure corresponding to the table passed into the message`r`n"

# Iterate through each table in the source database
foreach ($tbl in $db.Tables) {
    $tblnm = $tbl.Name
    $tblsch = $tbl.Schema
    $idx = $tbl.Indexes | where-object {$_.IndexKeyType -eq 'DriPrimaryKey'}
    $idxnm = $idx.Name
    $idc = $idx.IndexedColumns

    # Build the opening Transact-SQL for the source database trigger
    $trg += "IF OBJECT_ID ('$($tblsch).tr_$($tblnm)_IUD','TR') IS NOT NULL`r`n"
    $trg += "   DROP TRIGGER $($tblsch).tr_$($tblnm)_IUD `r`n"
    $trg += "GO`r`n"
    $trg += "`r`n"
    $trg += "CREATE TRIGGER $($tblsch).tr_$($tblnm)_IUD`r`n"
    $trg += "   ON  [$($tblsch)].[$($tblnm)]`r`n"
    $trg += "   FOR INSERT, UPDATE, DELETE`r`n"
    $trg += "AS `r`n"
    $trg += "`r`n"
    $trg += "  DECLARE @InitDlgHandle UNIQUEIDENTIFIER;`r`n"
    $trg += "  DECLARE @ChangeMsg XML;`r`n"
    $trg += "  DECLARE @ChangeCnt int;`r`n"
    $trg += "  DECLARE @Action char(1);`r`n"
    $trg += "  DECLARE @TableName varchar(100) = '$($tblsch)_$($tblnm)';`r`n"
    $trg += "  DECLARE @service_name nvarchar(512) = N'//$($dbnm)Sync/$($dbnm)SyncService';`r`n"
    $trg += "	`r`n"
    $trg += "  SELECT @InitDlgHandle=[ch]`r`n"
    $trg += "  FROM [dbo].[BrokerConversation]`r`n"
    $trg += "  WHERE [service_name] = @service_name;`r`n"
    $trg += "  `r`n"
    $trg += "  BEGIN TRY`r`n"
    $trg += "    IF USER_NAME() <> '$($syncusr)'`r`n"
    $trg += "    BEGIN`r`n"
    $trg += "`r`n"

    # Build the ProcessSyncData code to call the right stored procedure for the current message
    $psd += "                IF (@TableName = '$($tblsch)_$($tblnm)')`r`n"
    $psd += "                    BEGIN`r`n"
    $psd += "                    EXEC [$tblsch].[Process$($tblnm)] @messagebody;`r`n"
    $psd += "                    END`r`n"
    
    # Build the compare code to determine if the change is an Update, an Insert or a Delete
    $trg += "      -- If there are rows in both inserted and deleted, the change is an update`r`n"
    $trg += "      SELECT @ChangeCnt = count(*)`r`n"
    $trg += "        FROM [dbo].[Categories] t`r`n"
    $trg += "        INNER JOIN deleted d on`r`n"
    $j = 0
    $idcnt = $idc.Count
    foreach ($ic in $idc) {	# Iterate through the primary key columns building the join condition
       $j++
       $icnm = $ic.Name
       $trg += "            t.[$icnm] = d.[$icnm]"
       if ($j -eq $idcnt) {
          $trg += "`r`n"
          }
       else {
          $trg += " AND`r`n"
          }
	   }
    $trg += "        INNER JOIN inserted i on`r`n"
    $j = 0
    $idcnt = $idc.Count
    foreach ($ic in $idc) {	# Iterate through the primary key columns building the join condition
       $j++
       $icnm = $ic.Name
       $trg += "            t.[$icnm] = i.[$icnm]"
       if ($j -eq $idcnt) {
          $trg += "`r`n"
          }
       else {
          $trg += " AND`r`n"
          }
       }
    $trg += "      if (@ChangeCnt > 0)`r`n"
    $trg += "        BEGIN;`r`n"
    $trg += "        SET @Action = 'U';`r`n"
    $trg += "        END;`r`n"
    $trg += "      ELSE`r`n"
    $trg += "        BEGIN`r`n"
    $trg += "        -- Since rows aren't in both inserted and deleted, then the change is an insert or a delete`r`n"
    $trg += "        -- If there are rows in deleted, the change is a delete, and we only need the primary key value`r`n"
    $trg += "        select @ChangeCnt = count(*) from deleted`r`n"
    $trg += "        if (@ChangeCnt > 0)`r`n"
    $trg += "          BEGIN`r`n"
    $trg += "          SET @Action = 'D';`r`n"
    $trg += "          END;`r`n"
    $trg += "`r`n"
    $trg += "        -- If there are rows in inserted, the change is an insert and we need all the column values`r`n"
    $trg += "        select @ChangeCnt = count(*) from inserted`r`n"
    $trg += "        if (@ChangeCnt > 0)`r`n"
    $trg += "          BEGIN`r`n"
    $trg += "          SET @Action = 'I';`r`n"
    $trg += "          END;`r`n"
    $trg += "        END;`r`n"
    $trg += "`r`n"
      
    # Build the opening Transact-SQL for the destination database Process procedure
    $ddl += "IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[$tblsch].[Process$($tblnm)]') AND type in (N'P', N'PC'))`r`n"
    $ddl += "DROP PROCEDURE [$tblsch].[Process$($tblnm)]`r`n"
    $ddl += "GO`r`n"
    $ddl += "`r`n"
    $ddl += "CREATE PROCEDURE [$tblsch].[Process$($tblnm)]`r`n"
    $ddl += "	@messagebody XML`r`n"
    $ddl += "WITH EXECUTE AS '$($syncusr)'`r`n"
    $ddl += "AS`r`n"
    $ddl += "  SET NOCOUNT ON`r`n"
    $ddl += "  BEGIN TRY`r`n"
  
    # Build the column collection
    $clst = @()
    $identcol = ''
    $identdtl = @()
    
    # Flag if the XML or varbinary datatype is used
    $bindt = $False
    foreach ($col in $tbl.Columns) {	# Iterate through the columns building the DDL datatype collection for each
        $cnm = $col.Name
        $cdn = $col.DataType.Name
        $cdt = $col.DataType.SqlDataType
        $cln = [string]$col.DataType.MaximumLength
        $cnp = [string]$col.DataType.NumericPrecision
        $cns = [string]$col.DataType.NumericScale
        if (($cdt -eq 'Xml') -or ($cdt -like '*binary*')) {
           $bindt = $True
           }
        if ($cln -eq -1) {
            if ($cdt -eq 'Xml') {
                $dtype = $cdt
                }
            else {
                $dtype = "$cdn(max)"
                }
            }
        elseif (($cdt -like '*char*') -or ($cdt -like '*Char*') -or ($cdt -like '*binary*') -or ($cdt -like '*Binary*')) {
            $dtype = "$cdt($cln)"
            }
        elseif (($cdt -eq 'Numeric') -or ($cdt -eq 'Decimal')) {
            $dtype = "$cdt($cnp,$cns)"
            }
        else {
            $dtype = [string]$cdt
            }
        $mcol = New-Object System.Object
        $mcol | Add-Member -type NoteProperty -name Name -value $cnm
        $mcol | Add-Member -type NoteProperty -name DataType -value $dtype
        $clst += $mcol
        if ($col.Identity -eq $True) {	# Build a collection of identity details to populate the control table
           $identcol = $cnm
           $incr = $col.IdentityIncrement
           $iseed = $col.IdentitySeed
           $icol = New-Object System.Object
           $icol | Add-Member -type NoteProperty -name SchemaName -value $tblsch
           $icol | Add-Member -type NoteProperty -name TableName -value $tblnm
           $icol | Add-Member -type NoteProperty -name ColumnName -value $cnm
           $icol | Add-Member -type NoteProperty -name DataType -value $dtype
           $icol | Add-Member -type NoteProperty -name IDIncrement -value $incr
           $icol | Add-Member -type NoteProperty -name IDSeed -value $iseed
           $identdtl += $icol
           }
        }

    $trg += "      if (@Action = 'D')`r`n"
    $trg += "        BEGIN;`r`n"
    $trg += "        -- Build the XML message, flagging it as an update`r`n"
    $trg += "        set @ChangeMsg = (`r`n"
    $trg += "        SELECT @Action as [Action]`r`n"
    $trg += "              ,@TableName as [TableName]`r`n"
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the select statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        if ($cdt -eq 'Xml') {
           $trg += "              ,CONVERT(varbinary(max), t.[$cnm]) AS $cnm`r`n"
           }
        else {
           $trg += "              ,t.[$cnm]`r`n"
           }
        }
    $trg += "          FROM [$tblsch].[$tblnm] t`r`n"
    $trg += "          INNER JOIN deleted d on`r`n"
    $j = 0
    $idcnt = $idc.Count
    foreach ($ic in $idc) {	# Iterate through the primary key columns building the join condition
       $j++
       $icnm = $ic.Name
       $trg += "            t.[$icnm] = d.[$icnm]"
       if ($j -eq $idcnt) {
          $trg += "`r`n"
          }
       else {
          $trg += " AND`r`n"
          }
       }
    if ($bindt -eq $True) {
       $trg += "          FOR XML RAW, ELEMENTS, BINARY BASE64, ROOT ('$($dbnm)')`r`n"
       }
    else {
       $trg += "          FOR XML RAW, ELEMENTS, ROOT ('$($dbnm)')`r`n"
       }
    $trg += "          );`r`n"
    $trg += "        END;`r`n"
    $trg += "      ELSE`r`n"
    $trg += "        BEGIN;`r`n"
    $trg += "        -- Build the XML message, flagging it as an update`r`n"
    $trg += "        set @ChangeMsg = (`r`n"
    $trg += "        SELECT @Action as [Action]`r`n"
    $trg += "              ,@TableName as [TableName]`r`n"
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the select statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        if ($cdt -eq 'Xml') {
           $trg += "              ,CONVERT(varbinary(max), t.[$cnm]) AS $cnm`r`n"
           }
        else {
           $trg += "              ,t.[$cnm]`r`n"
           }
        }
    $trg += "          FROM [$tblsch].[$tblnm] t`r`n"
    $trg += "          INNER JOIN inserted i on`r`n"
    $j = 0
    $idcnt = $idc.Count
    foreach ($ic in $idc) {	# Iterate through the primary key columns building the join condition
       $j++
       $icnm = $ic.Name
       $trg += "            t.[$icnm] = i.[$icnm]"
       if ($j -eq $idcnt) {
          $trg += "`r`n"
          }
       else {
          $trg += " AND`r`n"
          }
       }
    if ($bindt -eq $True) {
       $trg += "          FOR XML RAW, ELEMENTS, BINARY BASE64, ROOT ('$($dbnm)')`r`n"
       }
    else {
       $trg += "          FOR XML RAW, ELEMENTS, ROOT ('$($dbnm)')`r`n"
       }
    $trg += "          );`r`n"
    $trg += "        END;`r`n"
    $trg += "`r`n"

    $ddl += "  CREATE TABLE #$($tblsch)_$($tblnm) (`r`n"
    $ddl += "`t" + '[Action] nchar(1) NULL,' + "`r`n"
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the create statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl += "`t[$cnm]  $cdt NULL"
        if ($i -lt $ccnt) {
            $ddl += ','
            }
        $ddl += "`r`n"
        if ($i -eq $ccnt) {
            $ddl += "`t)" + "`r`n"
            }
        }
    $ddl += "  INSERT INTO #$($tblsch)_$($tblnm)`r`n"
    $ddl += "  SELECT`r`n"
    $ddl += "`ta.value(N'(./Action)[1]', N'nchar(1)') as [Action],`r`n"

    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the XQuery statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        if ($cdt -eq 'Xml') {
           $ddl += [string]"`tCONVERT(XML, a.value(N'(./ScanImageFile)[1]', N'varbinary(max)')) as [$($cnm)]"
           }
        else {
           $ddl += [string]"`ta.value(N'(./$($cnm)/text())[1]', N'$($cdt)') as [$($cnm)]"
           }
        if ($i -lt $ccnt) {
            $ddl += ','
            }
        $ddl += "`r`n"
        if ($i -eq $ccnt) {
            $ddl += [string]"`tfrom @messagebody.nodes('/$dbnm/row') as r(a)`r`n"
            $ddl += [string]"`toption (optimize for (@messagebody = NULL));`r`n"
            }
        }
    $ddl += "`r`n"

    $ddl += "  -- Delete the existing rows for the incoming changes, then insert the ones that aren't deletes`r`n"
    $ddl += "`r`n"
    $ddl += "  DELETE cs`r`n"
    $ddl += "  FROM [$tblsch].[$tblnm] cs`r`n"
    $ddl += "  INNER JOIN #$($tblsch)_$($tblnm) t ON`r`n"
    $j = 0
    $idcnt = $idc.Count
    foreach ($ic in $idc) {	# Iterate through the primary key columns building the join condition
       $j++
       $icnm = $ic.Name
       $ddl += "`tcs.[$icnm] = t.[$icnm]"
       if ($j -eq $idcnt) {
          $ddl += "`r`n"
          }
       else {
          $ddl += " AND`r`n"
          }
       }
    $ddl += "`r`n"
    $ddl += "  DELETE`r`n"
    $ddl += "  FROM #$($tblsch)_$($tblnm)`r`n"
    $ddl += "  WHERE [Action] = 'D'`r`n"
    $ddl += "`r`n"

    if ($identcol -ne '') {
       $ddl += "  SET IDENTITY_INSERT [$tblsch].[$tblnm] ON`r`n"
       }
    $ddl += "  INSERT INTO [$tblsch].[$tblnm] (`r`n"
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the insert statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl += "`t[$cnm]"
        if ($i -lt $ccnt) {
            $ddl += ','
            }
        $ddl += "`r`n"
        if ($i -eq $ccnt) {
            $ddl += "`t)" + "`r`n"
            }
        }
    $ddl += '  SELECT ' + "`r`n"
    $i = 0
    $ccnt = $clst.Count
    foreach ($cl in $clst) {	# Iterate through the column collection building the select statement
        $i++
        $cnm = $cl.Name
        $cdt = $cl.DataType
        $ddl += "`t[$cnm]"
        if ($i -lt $ccnt) {
            $ddl += ','
            }
        $ddl += "`r`n"
        if ($i -eq $ccnt) {
            $ddl += "  FROM #$($tblsch)_$($tblnm)`r`n"
            }
        }
    if ($identcol -ne '') {
       $ddl += "  SET IDENTITY_INSERT [$tblsch].[$tblnm] OFF`r`n"
       }
    $ddl += "`r`n"

    # Finalize the trigger code
    $trg += "    IF @ChangeMsg IS NOT NULL`r`n"
    $trg += "      BEGIN`r`n"
    $trg += "      BEGIN TRANSACTION;`r`n"
    $trg += "      ;SEND ON CONVERSATION @InitDlgHandle`r`n"
    $trg += "           MESSAGE TYPE [//$($dbnm)Sync/$($dbnm)]`r`n"
    $trg += "           (@ChangeMsg);`r`n"
    $trg += "      --END CONVERSATION @InitDlgHandle;`r`n"
    $trg += "      COMMIT TRANSACTION;`r`n"
    $trg += "      END`r`n"
    $trg += "    END`r`n"
    $trg += "  END TRY`r`n"
    $trg += "  BEGIN CATCH`r`n"
    $trg += "  	IF XACT_STATE() <> 0`r`n"
    $trg += "  		BEGIN`r`n"
    $trg += "		-- Rollback any pending transaction`r`n"
    $trg += "		ROLLBACK TRANSACTION;`r`n"
    $trg += "		END`r`n"
    $trg += "`r`n"
    $trg += "	-- Insert the error information into the ErrorLog Categories for later reference`r`n"
    $trg += "  	INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,`r`n"
    $trg += "  		ErrorState, ErrorProcedure, ErrorLine, ErrorMessage)`r`n"
    $trg += "  	VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),`r`n"
    $trg += "  		ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE())`r`n"
    $trg += "`r`n"
    $trg += "  END CATCH`r`n"
    $trg += "`r`n"
    $trg += "GO`r`n"
    $trg += "`r`n"
    $trg += "EXEC sp_settriggerorder @triggername=N'[$($tblsch)].[tr_$($tblnm)_IUD]', @order=N'Last', @stmttype=N'DELETE'`r`n"
    $trg += "GO`r`n"
    $trg += "EXEC sp_settriggerorder @triggername=N'[$($tblsch)].[tr_$($tblnm)_IUD]', @order=N'Last', @stmttype=N'INSERT'`r`n"
    $trg += "GO`r`n"
    $trg += "EXEC sp_settriggerorder @triggername=N'[$($tblsch)].[tr_$($tblnm)_IUD]', @order=N'Last', @stmttype=N'UPDATE'`r`n"
    $trg += "GO`r`n"
    $trg += "`r`n"
    
    # Finalize the Process stored procedure code
    $ddl += '  END TRY' + "`r`n"
    $ddl += "`r`n"
    $ddl += '  BEGIN CATCH' + "`r`n"
    $ddl += '    -- Insert any errors into the ErrorLog table for later review and correction' + "`r`n"
    $ddl += '    INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,' + "`r`n"
    $ddl += '    	ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)' + "`r`n"
    $ddl += '    VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),' + "`r`n"
    $ddl += '    	ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)' + "`r`n"
    $ddl += '  ' + "`r`n"
    $ddl += '  END CATCH' + "`r`n"
    $ddl += "`r`n"
    $ddl += '  RETURN' + "`r`n"
    $ddl += "`r`n"
    $ddl += 'GO' + "`r`n"
    $ddl += "`r`n"
    }

# Finalize the ProcessSyncData code
$psd += "                -- Delete the message so it's only processed once`r`n"
$psd += "                DELETE FROM [dbo].[BrokerMessages]`r`n"
$psd += "                WHERE id = @id;`r`n"
$psd += "            END`r`n"
$psd += "            ELSE`r`n"
$psd += "            BEGIN`r`n"
$psd += "                -- If we're out of messages, wait a minute and then check again`r`n"
$psd += "                WAITFOR DELAY '00:01:00';`r`n"
$psd += "            END`r`n"
$psd += "`r`n"
$psd += "        END TRY`r`n"
$psd += "        BEGIN CATCH`r`n"
$psd += "`r`n"
$psd += "            INSERT INTO dbo.ErrorLog (ErrorTime, UserName, ErrorNumber, ErrorSeverity,`r`n"
$psd += "                ErrorState, ErrorProcedure, ErrorLine, ErrorMessage, MessageBody)`r`n"
$psd += "            VALUES (getdate(), USER_NAME(), ERROR_NUMBER(), ERROR_SEVERITY(),`r`n"
$psd += "                ERROR_STATE(), ERROR_PROCEDURE(), ERROR_LINE(), ERROR_MESSAGE(), @messagebody)`r`n"
$psd += "`r`n"
$psd += "        END CATCH`r`n"
$psd += "    END`r`n"
$psd += "GO`r`n"
$psd += "`r`n"
$ddl += $psd	# Add the ProcessSyncData code to the Process script

# Write the scripts to output files
$trg | out-file "./$($dbnm)Trig.sql"
$ddl | out-file "./$($dbnm)Sync.sql"
